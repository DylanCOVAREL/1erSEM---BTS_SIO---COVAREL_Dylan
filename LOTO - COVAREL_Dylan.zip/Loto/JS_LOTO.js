


alert("Les jeux d'argent sont interdit aux mineurs.");




function Flash(){
    let hasard = [];
    let list_aleat = [];
    for (let i=1;i<7;i++){
        hasard[i]=Math.floor(Math.random() * 49)+1;
        if (Analyse(hasard[i], list_aleat) == false){
        document.getElementById("num"+i).value = hasard[i];
        list_aleat.push(hasard[i]);
        } 
        else{
            i = i - 1;
        }
    }
}

function Analyse(a, list) {
	for (let t=0; t < list.length; t++) {
		if (a == list[t]){
			return true
		}
	}
	return false
}

function Tirage(){
    let hasard = [];
    let list_aleat = [];
    for (let i=1;i<7;i++){
        hasard[i]=Math.floor(Math.random() * 49)+1;
        if (Analyse(hasard[i], list_aleat) == false){
        document.getElementById("Result"+i).value = hasard[i];
        list_aleat.push(hasard[i]);
        } 
        else{
            i = i - 1;
        }
    }
    
}
 
function Comparaison(Numeros){
    let compteur = 0;
    for (let i=1;i<Numeros.length;i++){
        for(let p=1;p<val_tirage.length;p++){
            if (Numeros[i] == val_tirage[p]){
                compteur++
            }
        }
    }
    compt = compteur;
    if (compteur < 5){
        correspondance ="Tu as eu: "+compteur+" nombre(s)<br> réessaie"; 
    }else{
        return true
    }
}





//function Comparaison(){
    //let ChiffBon = 0
    //for (let i = 0; i<5; i++){
        //for (let t=0; t<5; t++){
            //if (("num"[i]) == Result1[t]){
                //ChiffBon = ChiffBon + 1
            //}
        //}
    //}
//}


