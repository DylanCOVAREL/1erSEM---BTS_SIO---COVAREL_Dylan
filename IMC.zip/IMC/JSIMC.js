//JavaScript de Dylan COVAREL
//Fait en novembre/décembre 2021
//Avec de l'aide Artur RICHARD

function maFonctionCalcul(){
    let idPoids = document.getElementById("idPoids").value  //let déféni la balise idPoids - document.getElementById sert à récupérer la balise dans le document HTML
    let idTaille = document.getElementById("idTaille").value
    let resultatIMC = document.getElementById("resultatIMC")
    let commentaire=""

    idIMC = idPoids / Math.pow(idTaille, 2) //début de la fonction de calcul d'IMC
    idIMC = idIMC.toFixed(2) //Sert à arrondir le résultat de l'IMC
    commentaire = evaluation(idIMC)

    resultat = "Votre IMC est de : " + idIMC+"<br/>"+commentaire  //Message qui affiche le résultat

    resultatIMC.innerHTML = resultat
    
}





function evaluation(IMC){ //fonction pour évaluer les valeurs, et afficher les commentaires au résultat
    
    let MsgDeRep= "Autrement dit : "

    if(IMC<10){
        MsgDeRep="Erreur, veuillez saisir des données valides."
    }

    else if(IMC<16.5){
        MsgDeRep=MsgDeRep + "Vous êtes en état de famine, méfiez-vous de votre santé !"
    }
    
    else if(IMC >=16.5 && IMC<18.5){
        MsgDeRep=MsgDeRep + "Vous êtes en état de maigreur."
    }

    else if(IMC >= 18.5 && IMC<25){
        MsgDeRep=MsgDeRep + "Vous avez une corpulence normale."
    }

    else if(IMC >= 25 && IMC<30){
        MsgDeRep=MsgDeRep + "Méfiez-vous, vous êtes en surpoids !"
    }

    else if(IMC >= 30 && IMC<35){
        MsgDeRep=MsgDeRep + "Méfiez-vous, vous êtes en obesité modérée !"
    }

    else if(IMC >= 35 && IMC<40){
        MsgDeRep=MsgDeRep + "Méfiez-vous, vous êtes en obesité sévère !"
    }

    else if(IMC > 40){
        MsgDeRep=MsgDeRep + "Vous êtes en obésité massive, méfiez-vous de votre santé !"
    }

    return MsgDeRep
}



//Programme principal
// JSIMC.innerHTML= calculPoidsTaille(14)
btnCalculer.addEventListener('click', maFonctionCalcul)