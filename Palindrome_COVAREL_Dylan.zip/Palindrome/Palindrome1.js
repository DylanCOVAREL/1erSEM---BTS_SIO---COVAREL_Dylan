/*Autre version testeur de Palindrome*/
/*Réalisé avec l'aide de Artur RICHARD*/
/*Janvier 2022*/


function Palindrome(){
    let chaine=document.getElementById("saisie_utilisateur").value;
    let chaineInver="";
    let Result=document.getElementById("Result");
    let resultat="";

    chaine=chaine.toLowerCase()
    tousAccents=["aáàåâãæä", "cç", "eèéêë", "iíìîï", "nñ", "oóòôöõœ", "uûùúü", "yýÿ"];
    for(let x=0; x<tousAccents.length; x++){
        chaine=NettoyageAccent(chaine, tousAccents [x]);
    }
    for(let i=string.length-1; i>=0; i--){
        chaineInver=chaineInver + chaine [i];
    }
    console.log(string, chaineInver);
    if(chaine==chaineInver){
        resultat=resultat + "C'est un palindrome.";
    }
    else if(chaine=chaineInver){
        resultat=resultat + "Ce n'est pas un palindrome.";
    }
    Result.innerHTML=resultat;
}





function NettoyageAccent(chaineA, accent){
    console.log(chaineA, accent);
    chaine=chaineA.split(" ");
    console.log(chaine);
    for(let t=0; t<accent.length; i++){
        for(let i=0; 1<chaine.length; i++){
            if(chaine[i]==accent[t]){
                console.log("remplacement de", chaineA[i], "par", accent[0]);
                chaine[i]=accent[0];
            }
        }
    }
    chaineA=chaine.join(" ");
    console.log(chaineA, accent);
    return chaineA;
}