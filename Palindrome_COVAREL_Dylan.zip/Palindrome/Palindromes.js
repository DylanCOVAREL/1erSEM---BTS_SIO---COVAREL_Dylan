/*Document JS 1 Testeur De Palindromes de Dylan COVAREL*/
/*Réalisé seul en décembre/janvier 2021/2022*/

/*fonction principal qui utilise les autres fonctions*/
function Palindrome(){
    let chaine = document.getElementById("saisie_utilisateur").value;
    chaine = chaine.toLowerCase();/*Met tout les caractères en minuscule*/    
    chaineInver = Inverse(chaine);
    chaine = NettoyageAccent(chaine);
    resultat = Eval(chaine, chaineInver);
}

/* La boucle récupère chaque caractère et les replaces en partant de la fin (de droite à gauche)*/
function Inverse(chaine){
    let chaineInver = "";
    for (let i = chaine.length - 1; i >= 0; i--){
        chaineInver = chaineInver + chaine[i];
    }
    return chaineInver;
}

/*Fonction qui supprime les accents*/
function NettoyageAccent(chaine){
    let tousAccents=["aáàâ", "cç", "eèéêë", "iíìï", "oóòôö", "uûùúü"];/*A peu près tous les accents rencontrable*/
    for(let t=0; t<tousAccents.length; t++){
        chaine = NettoyageAccent(chaine, tousAccents[t]);
    }
    return chaine
}

/*fonction qui interprète le résultat*/
function Eval(chaine, chaineInver){
    let erreur = "Veuiller saisir au moins deux lettres !"
    let juste = "C'est effectivement un Palindrome !"
    let faux = "Ce n'est pas un Palindrome !"
    
    if(chaine.length < 2){
        document.getElementById("Result").innerHTML = erreur;
    }
    else if(chaine == chaineInver){
        document.getElementById("Result").innerHTML = juste;
    }
    else{
        document.getElementById("Result").innerHTML = faux;
    }
}

























/*AUTRE TEST POUR PALINDROME*/


/*function palindromes(){
    var str_entry = document.getElementById("saisie").value;
    var cstr = str_entry.toLowerCase().replace(/[â-zA-Z0-9]+/g,'');
    var ccount = 0;
*/    





/*    if(cstr===""){
        console.log("Chaine vide !");
        return false;
    }

    if((cstr.length) % 2 ===0){
        ccount = (cstr.length) / 2;
    
    }
    
    else{
        if(cstr.length === 1){
            return document.getElementById("saisie").innerHTML = "<p>C'est un palindrome.</p>";
        }
    
    else{
        ccount = (cstr.length - 1) / 2;
        }    
    }

    for (var x = 0; x < ccount; x++){
        if (cstr[x] !=cstr.slice(-1-x)[0]){
            return document.getElementById("saisie").innerHTML = "<p>Ce n'est pas un palindrome.</p>";
        }
    }

    return document.getElementById("saisie").innerHTML = "<p>Ce n'est pas un palindrome.</p>";

} */

/*function inverse(mot) {
    let motInv = "";
    for (let i = mot.length - 1; i >= 0; i--) {
        motInv + = mot[i];
    }
    return mot_inv;
}*/